﻿

$(function () {

    $('#btn1').attr('onclick', 'myFunction()');

    $('#imput1').attr('onkeydown', 'myFunction1()');

    $('#nome').attr("onkeyup", "myFunction2()");

    $('#copiar').attr('oncopy', 'myFunction()');

    $('#Colar').attr('onpaste', 'myFunctionColar()');

});



function myFunction() {
    document.getElementById("resultado").innerHTML = "Ola você clicou";
}


function myFunction1() {
    alert('você digitou');
}


function myFunction2() {
    var texto = document.getElementById('nome');

    texto.value = texto.value.toUpperCase();
}


function myFunction() {
    //document.getElementById('resultado1').innerHTML = 'Texto copiado !';

    $('#resultado1').text('Texto Copiado !!!');
}


function myFunctionColar() {
    $('#resultado2').text('Você colou um texto aqui !!!');
}